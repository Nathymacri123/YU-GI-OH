package com.example.yu_gi_oh.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.LinearProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.yu_gi_oh.R
import com.example.yu_gi_oh.navigation.AppNav
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(navController: NavController){
    LaunchedEffect(key1 = true){
        delay(4000)
        navController.popBackStack()
        navController.navigate(AppNav.LoginScreen.route)
    } // fin LaunchedEffect
    Splash()
} // fin SplashScreen
@Composable
fun Splash(){
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
       Image(painter = painterResource(R.drawable.logo), contentDescription = "",
       Modifier.size(300.dp, 300.dp))
        Text(text = "Cargando...",
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
        ) // fin Text

        //CircularProgressIndicator(
          //  modifier = Modifier.padding(16.dp),
            //color = MaterialTheme.colors.primary,
            //strokeWidth = Dp(value = 4F)
        //)
        LinearProgressIndicator(
            progress =  0.9f,
            color = MaterialTheme.colors.primary,
        ) // fin LinearProgressIndicator
    } // fin Column
} // fin Splash