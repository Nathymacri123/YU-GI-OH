package com.example.yu_gi_oh.modelos

data class Datos(
    val namemail: String = "",
    val fotoemail : String = "",
    val usuemail : String = "",
)
