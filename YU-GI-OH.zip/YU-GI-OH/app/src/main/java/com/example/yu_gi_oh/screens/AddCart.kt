package com.example.yu_gi_oh.screens

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.Image
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.yu_gi_oh.R
import com.example.yu_gi_oh.modelos.Carta
import com.example.yu_gi_oh.navigation.AppNav
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddCart(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar {
                Text(
                    text = "¡YU.GI-HO!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.Black
                ) // fin Text
            } // Fin TopAppBar
        }, // Fin topBar
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route = AppNav.Home.route) }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Regresar",
                    tint = Color.White
                ) // Fin Icon
            } // Fin FloatingActionButton
        }, // Fin floatingActionButton
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent()
    } // Fin de BodyContent()
} // Fin AddScreen

@Composable
fun BodyContent() {
    var nombre by remember { mutableStateOf("") }
    var foto by remember { mutableStateOf("") }
    var poder by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val logo = painterResource(R.drawable.logo)
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 30.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Image(
                    modifier = Modifier
                        .size(300.dp)
                        .fillMaxWidth()
                        .fillMaxHeight(0.3f)
                        .padding(all = 10.dp),
                    painter = logo,
                    contentDescription = null)

                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White),
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre") },
                    maxLines = 5,
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(
                                imageVector = Icons.Default.Face ,
                                contentDescription = "",
                                tint = MaterialTheme.colors.primary,)
                        } // fin IconButton
                    }, // fin leadingIcon
                    trailingIcon = {
                        IconButton(onClick = { Log.d("Trailing Icon", "Clicked") }) {
                            Icon(imageVector = Icons.Default.Check , contentDescription = "")
                        } // fin IconButton
                    } // fin trailingIcon
                ) // fin TextFiel
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White),
                    value = foto,
                    onValueChange = { foto = it },
                    label = { Text("Foto") },
                    maxLines = 5,
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = "",
                                tint = MaterialTheme.colors.primary,)
                        } // fin IconButton
                    }, // fin leadingIcon
                    trailingIcon = {
                        IconButton(onClick = { Log.d("Trailing Icon", "Clicked") }) {
                            Icon(imageVector = Icons.Default.Check , contentDescription = "")
                        } // fin IconButton
                    } // fin trailingIcon
                ) // fin TextField
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White),
                    value = poder,
                    onValueChange = { poder = it },
                    label = { Text("Poder") },
                    maxLines = 5,
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(
                                imageVector = Icons.Default.Construction,
                                contentDescription = "",
                                tint = MaterialTheme.colors.primary,)
                        } // fin IconButton
                    }, // fin leadingIcon
                    trailingIcon = {
                        IconButton(onClick = { Log.d("Trailing Icon", "Clicked") }) {
                            Icon(imageVector = Icons.Default.Check , contentDescription = "")
                        } // fin IconButton
                    }// fin trailingIcon
                ) // fin TextField
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White),
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripcion") },
                    maxLines = 5,
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = "",
                                tint = MaterialTheme.colors.primary,)
                        } // fin IconButton
                    }, // fin leadingIcon
                    trailingIcon = {
                        IconButton(onClick = { Log.d("Trailing Icon", "Clicked") }) {
                            Icon(imageVector = Icons.Default.Check , contentDescription = "")
                        } // fin IconButton
                    }// fin trailingIcon
                ) // fin TextField
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White),
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL") },
                    maxLines = 5,
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(
                                imageVector = Icons.Default.Link,
                                contentDescription = "",
                                tint = MaterialTheme.colors.primary,)
                        } // fin IconButton
                    }, // fin leadingIcon
                    trailingIcon = {
                        IconButton(onClick = { Log.d("Trailing Icon", "Clicked") }) {
                            Icon(imageVector = Icons.Default.Check , contentDescription = "")
                        } // fin IconButton
                    }// fin trailingIcon
                ) // fin TextField
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        if (nombre == "" ||foto == "" || poder == "" || descripcion == "" || url == "") {
                            error = true
                        } else {
                            val cartas = Carta(nombre,foto, poder, descripcion, url)
                            Firebase.firestore.collection("Cartas").add(cartas)
                        } // Fin If
                    }, //Fin onClick
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                ) {
                    Text(text = "AGREGAR POKEMON")
                    Icon(imageVector = Icons.Default.NoteAdd , contentDescription = "")
                } // Fin Button
                if (error) {
                    AlertDialog()
                } // Fin If
            } // Fin Item
        } // Fin LazyColumn
    } // Fin Box
} // Fin BodyContent

@Composable
fun AlertDialog() {
    val content = LocalContext.current
    val openDialog = remember { mutableStateOf(true) }

    if (openDialog.value) {
        AlertDialog(
            onDismissRequest = { openDialog.value = false },
            title = { Text(text = "¡ERROR!", color = Color.Black,) },
            text = { Text(text = "¡TODOS LOS CAMPOS DEBEN DE ESTAR LLENOS!", color = Color.Black,
            ) },

            confirmButton = {
                TextButton(
                    onClick = {
                        openDialog.value = false
                        Toast.makeText(content, "Aceptada con exito!", Toast.LENGTH_SHORT).show()
                    } // Fin onClick
                ) {
                    Text(text = "Aceptar")
                } // Fin TextButton
            }, // Fin  confirmButton
            dismissButton = {
                TextButton(
                    onClick = {
                        openDialog.value = false
                        Toast.makeText(content, "Cancelada con exito!", Toast.LENGTH_SHORT).show()
                    } // Fin onClick
                ) {
                    Text(text = "Cancelar")
                } // Fin TextButton
            }, // Fin dismissButton
            contentColor = Color.White
        ) // Fin AlertDialog
    } // Fin If
} // Fin AlertDialog