package com.example.yu_gi_oh.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.yu_gi_oh.screens.*
import com.example.yu_gi_oh.modelos.CartaViewModel
import com.example.yu_gi_oh.screens.login.LoginScreen
import com.example.yu_gi_oh.screens.login.MainViewModel

@Composable
fun AppNavigation(
    avanza: Boolean,
    onClick: () -> Unit,
    cerrarSesion: () -> Unit,
    mainViewModel: MainViewModel,
){
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.SplashScreen.route
    ){
        composable(route = AppNav.SplashScreen.route) { SplashScreen(navController) }
        composable(route = AppNav.LoginScreen.route) {
            if (avanza) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(AppNav.Home.route)
                    {
                        popUpTo(AppNav.LoginScreen.route) {
                            inclusive = true
                        } // Fin popUpTo
                    } // Fin Modificacion
                } // Fin LaunchedEffect
            } else {
                LoginScreen(
                    navController,
                    isLoading = false,
                    onLoginClick = onClick)
            } // Fin If
        } // Fin Composable LoginScreen

        composable(route = AppNav.Home.route) { Home(navController, cerrarSesion) }
        composable(route = AppNav.ListCart.route) {
            ListCart(
                mainViewModel.state.value.fotoemail,
                mainViewModel.state.value.namemail,
                mainViewModel.state.value.usuemail,
                navController,
                CartaViewModel()
            )
        } // Fin Composable ListCart
        composable(route = AppNav.AddCart.route) { AddCart(navController) }
        composable(route = AppNav.InfoCart.route, arguments = listOf(
            navArgument("nombre") { type = NavType.StringType },
            navArgument("foto") { type = NavType.StringType },
            navArgument("poder") { type = NavType.StringType },
            navArgument("descripcion") { type = NavType.StringType },
            navArgument("url") { type = NavType.StringType }
        )){
            InfoCart(
                navController,
                nombre = it.arguments?.getString("nombre") ?: "",
                foto = it.arguments?.getString("foto") ?: "",
                poder = it.arguments?.getString("poder") ?: "",
                descripcion = it.arguments?.getString("descripcion") ?: "",
                url = it.arguments?.getString("url") ?: ""
            ) // Fin InfoCart
        } // Fin composable InfoCart
    } // Fin NavHost
} // Fin AppNavigation