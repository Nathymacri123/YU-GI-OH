package com.example.yu_gi_oh.modelos

data class Carta(
    val nombre: String="",
    val foto: String = "",
    val poder: String = "",
    val descripcion: String = "",
    val url: String = "",
)