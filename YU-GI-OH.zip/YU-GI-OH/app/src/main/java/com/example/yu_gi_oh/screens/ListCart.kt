package com.example.yu_gi_oh.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.yu_gi_oh.R
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import coil.compose.rememberAsyncImagePainter
import com.example.yu_gi_oh.modelos.Carta
import com.example.yu_gi_oh.modelos.CartaViewModel
import com.example.yu_gi_oh.navigation.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun ListCart(
    fotoemail: String,
    namemail: String,
    usuemail: String,
    navController: NavController,
    viewModel: CartaViewModel,
) {
    var showMenu by remember{ mutableStateOf(false ) }
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ){
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {

                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.Home.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.CatchingPokemon,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        Text(text = "Agrega",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold)
                    } // Fin Column MY MOVIES
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.ListCart.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.CatchingPokemon,
                            contentDescription = null,
                            tint = MaterialTheme.colors.primary
                        )
                        Text(text = "Card",
                            color = MaterialTheme.colors.primary,
                            fontWeight = FontWeight.Bold)
                    } // Fin Column MOVIES LIST
                    Column(verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { showMenu = !showMenu })
                    {
                        IconButton(onClick = { showMenu = !showMenu }) {
                            Icon(
                                imageVector = Icons.Default.Pending,
                                contentDescription = null,
                                tint = Color.Black)
                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false },
                                modifier = Modifier
                                    .width(300.dp)
                                    .height(160.dp)
                                    .padding(8.dp)) {
                                DropdownMenuItem(onClick = { /*TODO*/ }) {
                                  Column (
                                      verticalArrangement = Arrangement.Center,
                                      horizontalAlignment = Alignment.CenterHorizontally) {
                                      Image(
                                          modifier = Modifier
                                              .size(84.dp),
                                          painter = rememberAsyncImagePainter(fotoemail),
                                          contentDescription = null,
                                          contentScale = ContentScale.Crop
                                      ) // Fin Image
                                      Text(text = namemail)
                                      Text(text = usuemail)
                                  } // Column
                                } // fin DropdownMenuItem
                            } // fin DropdownMenu
                        } // fin IconButton
                    } // Fin Column
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ) // Fin Scaffold
    {
        var textUser by remember { mutableStateOf("") }
        var pasa by remember { mutableStateOf(false) }
        fun buscar() {
            if (textUser == "" || textUser.length <= 2) {
                pasa = false
            } else {
                for (datos in viewModel.Carta.value) {
                    if (datos.nombre.toString() == textUser.toString()) {
                        pasa = true
                    } // Fin If Intern
                } // Fin For
            } // // Fin If Externo
        } // buscar
        Column {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .width(1000.dp)
                            .height(50.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TextField(value = textUser, onValueChange = { textUser = it },
                            label = { Text(text = "Buscar")}// fin label
                        ) // fin TextField
                        Icon(imageVector = Icons.Default.Search, contentDescription = null,
                            tint = MaterialTheme.colors.primary,
                            modifier = Modifier
                                .size(30.dp)
                                .clickable { buscar() })
                    } // Fin Row
                    Spacer(modifier = Modifier.height(5.dp))
                } // Fin item
                if (!pasa) {
                     items(viewModel.Carta.value) { carta1 ->
                        CartaCard(carta1, navController)
                    } // Fin Items
                } else {
                    items(viewModel.Carta.value) { carta1 ->
                        if (carta1.nombre == textUser) {
                            CartaCard(carta1, navController)
                            FloatingActionButton(
                                modifier = Modifier.size(30.dp),
                                onClick = { pasa = false }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Regresar",
                                    tint = Color.White
                                ) // Fin Icon
                            } // Fin del onClick
                        } // Fin If Intern
                    } // Fin Items
                } // Fin If Externo
            } // Fin LazyColumn
        } // Fin Column-Box
    } //Fin Scaffold
} // Fin ListCart

@Composable
fun CartaCard(carta: Carta, navController:NavController) {
    val esfera = painterResource(R.drawable.esfera)
    var isFavorite by remember{ mutableStateOf(false) }
    Card(
        elevation = 6.dp, shape = RoundedCornerShape(25.dp),
        modifier = Modifier
            .height(165.dp)
            .fillMaxWidth()
            .padding(8.dp)
            .clickable {
                navController.navigate(
                    AppNav.InfoCart.new_route(
                        carta.nombre,
                        carta.foto,
                        carta.poder,
                        carta.descripcion,
                        carta.url
                    )
                )
            } // Fin clickable
    ){
        Row(modifier = Modifier.fillMaxSize()) {
            Image(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                painter = rememberAsyncImagePainter(carta.foto),
                contentDescription = null,
                contentScale = ContentScale.Crop
            ) // Fin Image
            Column(modifier = Modifier
                .fillMaxSize()
                .weight(2f)
                .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = carta.nombre,
                    color = Color.Black,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp, )
                Text(
                    text = carta.poder,
                    color = Color.Black,
                    fontSize = 20.sp,)
                Row() {
                    Image(
                        modifier = Modifier
                            .size(30.dp),
                        painter = esfera,
                        contentDescription = null)
                    Image(
                        modifier = Modifier
                            .size(30.dp),
                        painter = esfera,
                        contentDescription = null)
                    Image(
                        modifier = Modifier
                            .size(30.dp),
                        painter = esfera,
                        contentDescription = null)
                } // fin Row
                Icon(
                    modifier= Modifier
                        .align(Alignment.End)
                        .clickable {
                            isFavorite = !isFavorite
                        },
                    imageVector =
                    if (isFavorite)Icons.Default.Favorite else
                        Icons.Default.FavoriteBorder , contentDescription = null,
                    tint = if(isFavorite) Color.Red else Color.Black)
            } // fin Column
        } // Fin Row
    }// fin Card
} // Fin CartaCard