package com.example.yu_gi_oh.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import com.example.yu_gi_oh.R
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.yu_gi_oh.navigation.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Home(
    navController: NavController,
    cerrarSesion: () -> Unit
) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { cerrarSesion()
                            Handler(Looper.getMainLooper()).postDelayed({
                                navController.navigate(AppNav.LoginScreen.route)
                            }, 2000) }) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = null,
                            tint = Color.Black)
                        Text(
                            text = "Logout",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold)
                    } // fin Column 1
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.Home.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.CatchingPokemon,
                            contentDescription = null,
                            tint = MaterialTheme.colors.primary)
                        Text(
                            text = "Agrega",
                            color = MaterialTheme.colors.primary,
                            fontWeight = FontWeight.Bold)
                    } // Fin Column 2
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.ListCart.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.CatchingPokemon,
                            contentDescription = null,
                            tint = Color.Black)
                        Text(
                            text = "Card",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold)
                    } // Fin Column Interno3

                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ) {
        BodyContent(navController)
    } // Fin Scaffold
} // Fin Home

@Composable
fun BodyContent(
    navController: NavController
) {
    var isFavorite1 by remember { mutableStateOf(false) }
    var isFavorite2 by remember { mutableStateOf(false) }
    var isFavorite3 by remember { mutableStateOf(false) }
    var carta1 by remember { mutableStateOf(400) }
    var carta2 by remember { mutableStateOf(400) }
    var carta3 by remember { mutableStateOf(400) }
    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState()),
    ) {
        Card(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            elevation = 8.dp,
            shape = RoundedCornerShape(8.dp)
        ) {
            Column() {
                Image(
                    modifier = Modifier
                        .size(carta1.dp)
                        .clickable {
                            if (carta1 == 400) {
                                carta1 = 450
                            } else {
                                carta1 = 400
                            }
                        },
                    painter = painterResource(R.drawable.carta1),
                    contentDescription = null) // fin Image
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Kaibaman",
                        style = MaterialTheme.typography.h3)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box() {
                            Row() {
                                TextButton(onClick = { /*TODO*/ }) {
                                    Text(text = "SUPER")
                                } // fin TextButton
                                TextButton(onClick = { /*TODO*/ }) {
                                    Text(text = "HEROE")
                                } // fin TextButton
                            } // Row
                        } // fin Box
                        Box() {
                            Row() {
                                IconButton(onClick = {/*TODO*/ }) {
                                    Icon(
                                        modifier = Modifier.clickable {
                                            isFavorite1 = !isFavorite1
                                        },
                                        imageVector =
                                        if (isFavorite1) Icons.Default.Favorite else
                                            Icons.Default.FavoriteBorder,
                                        contentDescription = null,
                                        tint = if (isFavorite1) Color.Red else Color.Black)
                                }  // fin IconButton
                                IconButton(onClick = { /*TODO*/ }) {
                                    IconButton(onClick = { /*TODO*/ }) {
                                        Icon(
                                            imageVector = Icons.Filled.Share,
                                            contentDescription = "BotonFavorito")
                                    } // fin IconButton
                                } // fin IconButton
                            } // fin Row
                        } // fin Box
                    } // fin Row
                } //fin Column2
            } // fin Column1
        } // fin card1

        Card(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            elevation = 8.dp,
            shape = RoundedCornerShape(8.dp)
        ) {
            Column() {
                Image(
                    modifier = Modifier
                        .size(carta2.dp)
                        .clickable {
                            if (carta2 == 400) {
                                carta2 = 450
                            } else {
                                carta2 = 400
                            }
                        },
                    painter = painterResource(R.drawable.carta2),
                    contentDescription = null)
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Dragon Toon",
                        style = MaterialTheme.typography.h3
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box() {
                            Row() {
                                TextButton(onClick = { /*TODO*/ }) {
                                    Text(text = "SUPER")
                                } // fin TextButton
                                TextButton(onClick = { /*TODO*/ }) {
                                    Text(text = "HEROE")
                                } // fin TextButton
                            } // Row
                        } // fin Box
                        Box() {
                            Row() {
                                IconButton(onClick = { /*TODO*/ }) {
                                    IconButton(onClick = { /*TODO*/}) {
                                        Icon(
                                            modifier = Modifier.clickable {
                                                isFavorite2 = !isFavorite2 },
                                            imageVector =
                                            if (isFavorite2) Icons.Default.Favorite else
                                                Icons.Default.FavoriteBorder,
                                            contentDescription = null,
                                            tint = if (isFavorite2) Color.Red else Color.Black)
                                    } // fin IconButton
                                } // fin IconButton
                                IconButton(onClick = {  }) {
                                    IconButton(onClick = { /*TODO*/ }) {
                                        Icon(
                                            imageVector = Icons.Filled.Share,
                                            contentDescription = "Compartir")
                                    } // fin IconButton
                                } // fin IconButton
                            } // fin Row
                        } // fin Box
                    } // fin Row
                } //fin Column2
            } // fin Column1
        } // fin card2

        Card(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            elevation = 8.dp,
            shape = RoundedCornerShape(8.dp)
        ) {
            Column() {
                Image(
                    modifier = Modifier
                        .size(carta3.dp)
                        .clickable {
                            if (carta3 == 400) {
                                carta3 = 450
                            } else {
                                carta3 = 400
                            }
                        },
                    painter = painterResource(R.drawable.carta3),
                    contentDescription = null,
                )
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Feiticeira Negra",
                        style = MaterialTheme.typography.h3)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box() {
                            Row() {
                                TextButton(onClick = { /*TODO*/ }) {
                                    Text(text = "SUPER")
                                } // fin TextButton
                                TextButton(onClick = { /*TODO*/ }) {
                                    Text(text = "HEROE")
                                } // fin TextButton
                            } // fin Row
                        } // fin Box
                        Box() {
                            Row() {
                                IconButton(onClick = { /*TODO*/ }) {
                                    IconButton(onClick = { /*TODO*/ }) {
                                        Icon(
                                            modifier = Modifier.clickable {
                                                isFavorite3 = !isFavorite3
                                            },
                                            imageVector =
                                            if (isFavorite3) Icons.Default.Favorite else
                                                Icons.Default.FavoriteBorder,
                                            contentDescription = null,
                                            tint = if (isFavorite3) Color.Red else Color.Black)
                                    } // fin IconButton
                                } // fin IconButton
                                IconButton(onClick = { /*TODO*/ }) {
                                    IconButton(onClick = { /*TODO*/ }) {
                                        Icon(

                                            imageVector = Icons.Filled.Share,
                                            contentDescription = "BotonFavorito")
                                    } // fin IconButton
                                } // fin IconButton
                            } // fin Row
                        } // fin Box
                    } // fin Row
                } //fin Column2
            } // fin Column1
        } // fin card3
        Spacer(modifier = Modifier.height(10.dp))
            Button(
                modifier = Modifier
                    .padding(vertical = 8.dp, horizontal = 5.dp)
                    .fillMaxWidth(),
                onClick = { navController.navigate(AppNav.AddCart.route)}) {
                Text(text = "AGREGAR POKEMON")
                Icon(imageVector = Icons.Default.NoteAdd , contentDescription = "")
        } // fin Button
    } // fin Column principal
} // Fin BodyContent

