package com.example.yu_gi_oh

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import com.example.yu_gi_oh.navigation.AppNavigation
import com.example.yu_gi_oh.screens.login.MainViewModel
import com.example.yu_gi_oh.ui.theme.YUGIOHTheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.tasks.Task

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: MainViewModel by viewModels()
            val isLoading by viewModel.isLoading().observeAsState(false)
            val avanzar by viewModel.avance().observeAsState(false)
            YUGIOHTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    AppNavigation(
                        avanzar,
                        onClick = { viewModel.LoginWithGoogle(this@MainActivity) },
                        cerrarSesion= { viewModel.singOut(this@MainActivity) },
                        mainViewModel = viewModel
                    )
                }
            }
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val viewModel: MainViewModel by viewModels()
        if (requestCode == 1) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            viewModel.finishLogin(task)
        }
    }// fin segundo override

    fun shareimage(){
        val intent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "https://www.bing.com/images/search?view=detailV2&ccid=F%2b1AJ4k0&id=D7BAF8F4E03BC25F475E204522A3EFDBB3AE49E6&thid=OIP.F-1AJ4k0Ie4jKHJnswp4bQAAAA&mediaurl=https%3a%2f%2funicorncards.co.uk%2fimages%2fthumbs%2f0017831_sddc-en022-kaibaman-unl-edition-mint-yugioh-card.jpeg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.17ed4027893421ee23287267b30a786d%3frik%3d5kmus9vvoyJFIA%26pid%3dImgRaw%26r%3d0&exph=600&expw=418&q=carta+kaibaman&simid=608050795573152469&FORM=IRPRST&ck=AFAF733A6109C1F0E088B66266E2331F&selectedIndex=2")
        }
        val shareIntent = Intent.createChooser(intent, null)
        startActivity(shareIntent)
    }
}

