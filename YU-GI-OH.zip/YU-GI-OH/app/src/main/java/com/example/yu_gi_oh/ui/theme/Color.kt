package com.example.yu_gi_oh.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFEEBBA1)
val Purple500 = Color(0xFFDF5C17)
val Purple700 = Color(0xFFCF8E40)
val Teal200 = Color(0xFFDFB193)