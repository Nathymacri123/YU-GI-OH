package com.example.yu_gi_oh.modelos

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class CartaViewModel : ViewModel() {
    private val _Carta = mutableStateOf<List<Carta>>(emptyList())
    val Carta: State<List<Carta>>
        get() = _Carta
    private val query = Firebase.firestore.collection("Cartas")
    init {
        query.addSnapshotListener { value, _ ->
            if (value != null) {
                _Carta.value = value.toObjects()
            } //fin If
        } //fin query.addSnapshotListener
    } //fin init
} //fin CartaViewModel