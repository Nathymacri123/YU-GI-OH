package com.example.yu_gi_oh.screens.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.yu_gi_oh.R

@Composable
fun LoginScreen(
    navController: NavHostController,
    isLoading: Boolean,
    onLoginClick: () -> Unit,
) {
    val logo = painterResource(R.drawable.logo)
    val esfera = painterResource(R.drawable.esfera)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        Image(
            modifier = Modifier
                .size(300.dp)
                .fillMaxWidth()
                .fillMaxHeight(0.3f)
                .padding(all = 10.dp),
            painter = logo,
            contentDescription = null)
        Row() {
            Image(
                modifier = Modifier
                    .size(70.dp),
                painter = esfera,
                contentDescription = null)

            Image(
                modifier = Modifier
                    .size(70.dp),
                painter = esfera,
                contentDescription = null)
            Image(
                modifier = Modifier
                    .size(70.dp),
                painter = esfera,
                contentDescription = null)
        }

        Text(text = "!BIENVENIDOS¡",
            style = MaterialTheme.typography.h5,
            textAlign = TextAlign.Center,
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic,)
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            Button(
                onClick = onLoginClick,

            ) {
                Text(stringResource(R.string.Login_cta))
                Icon(imageVector = Icons.Default.Login, contentDescription = "")
            } // Fin Button
        } //  Fin If
        LegalText()
    } // Fin Column
} // Fin LoginScreen

@Composable
fun LegalText() {
    val anottatedString = buildAnnotatedString {
        append(" ")
        pushStringAnnotation("URL", "app://terms")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold
            )
        ) {
            append(stringResource(R.string.Text_Legal2))
        } // Fin withStyle
        append(" ")
        pop()
        append(stringResource(R.string.Text_Legal3))
        append(" ")
        pushStringAnnotation("URL", "app://privacy")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold
            )
        ) {
            append(stringResource(R.string.Text_Legal4))
        } // Fin withStyle
        pop()
    } //fin anottatedString
    Box(contentAlignment = Alignment.Center) {
        ClickableText(
            modifier = Modifier.padding(24.dp),
            text = anottatedString
        ) { offset ->
            anottatedString.getStringAnnotations("URL", offset, offset)
                .firstOrNull()?.let { tag ->
                    Log.d("App", "Ha dado cick en ${tag.item}")
                } //fin del Offset
        } // Fin Text
    } // fin Box
} //fin LegalText
