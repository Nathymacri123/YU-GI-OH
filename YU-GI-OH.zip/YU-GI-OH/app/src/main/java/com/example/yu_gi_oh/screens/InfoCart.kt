package com.example.yu_gi_oh.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.yu_gi_oh.navigation.AppNav
import com.example.yu_gi_oh.R

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun InfoCart(
    navController: NavController,
    nombre: String,
    foto: String,
    poder: String,
    descripcion: String,
    url: String,
) {
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(15.dp),
                horizontalArrangement = Arrangement.SpaceBetween,

            ) {
                Icon(
                    modifier = Modifier.clickable { navController.navigate(AppNav.ListCart.route)},
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = null,
                    tint = Color.Black
                )
                Text(text = "DETAILS")
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = Color.Black)
            } // Fin Row
        }, // Fin topBar
    ) {
        BodyInformation(navController,nombre, foto, poder, descripcion, url)
    } // Fin Scaffold
} // Fin InformacionPeli

@SuppressLint("SuspiciousIndentation")
@Composable
fun BodyInformation(
    navController: NavController,
    nombre: String,
    foto: String,
    poder: String,
    descripcion: String,
    url: String,
) {
    val esfera = painterResource(R.drawable.imagen1)
    val esfera1 = painterResource(R.drawable.bola3)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(all = 30.dp)
            .background(color = MaterialTheme.colors.primary),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .background(color = MaterialTheme.colors.primary),
        elevation = 8.dp,
        shape = RoundedCornerShape(8.dp),
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .background(color = MaterialTheme.colors.primary)

        ) {
            Card(
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colors.primary),
                elevation = 10.dp,
                shape = RoundedCornerShape(8.dp)
            ) {
                Row() {
                    Column() {
                        Text(
                            modifier = Modifier
                                .padding(horizontal = 5.dp),
                            text = nombre,
                            style = MaterialTheme.typography.h4)
                    } // fin Column
                    Column() {

                        Image(
                            modifier = Modifier
                                .width(50.dp)
                                .height(50.dp)
                                .padding(horizontal = 5
                                    .dp),
                            painter = esfera1,
                            contentDescription = null)
                    } // fin Column
                } // fin Row
            } // Fin Card

            Row(
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(6.dp)
            ) {
                Image(
                    modifier = Modifier
                        .size(30.dp),
                    painter = esfera,
                    contentDescription = null
                )
                Image(
                    modifier = Modifier
                        .size(30.dp),
                    painter = esfera,
                    contentDescription = null
                )
                Image(
                    modifier = Modifier
                        .size(30.dp),
                    painter = esfera,
                    contentDescription = null)
                Image(
                    modifier = Modifier
                        .size(30.dp),
                    painter = esfera,
                    contentDescription = null)
                Image(
                    modifier = Modifier
                        .size(30.dp),
                    painter = esfera,
                    contentDescription = null)
            } // fin Row
            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
            ) {
                Image(
                    modifier = Modifier
                        .padding(horizontal = 23.dp)
                        .width(400.dp)
                        .height(230.dp)
                        .border(6.dp, color = Color.DarkGray, shape = RoundedCornerShape(5.dp)),
                    painter = rememberAsyncImagePainter(foto),
                    contentDescription = "Imagen",
                    contentScale = ContentScale.FillWidth)
            } // fin Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box() {
                    Row() {
                        Text(
                            text = "1ra Edition",
                            fontWeight = FontWeight.Bold)
                    } // fin Row
                } // fin Box
                Box() {
                    Row() {
                        Text(
                            text = "YGOA-EN001",
                            fontWeight = FontWeight.Bold)
                    } // fin Row
                } // fin Box
            } // fin Row
            Card(
                modifier = Modifier
                    .padding(horizontal = 5.dp)
                    .fillMaxWidth()
                    .border(2.dp, color = Color.DarkGray, shape = RoundedCornerShape(5.dp))
            ) {
                Column() {
                    Row() {
                        Text(
                            modifier = Modifier
                                .padding(horizontal = 10.dp),
                            text = poder,
                            style = MaterialTheme.typography.h6)
                    } // fin Row
                    Row() {
                        Text(
                            modifier = Modifier
                                .padding(horizontal = 10.dp),
                            text = descripcion,
                            style = MaterialTheme.typography.body1)
                    } // fin Row
                    Row() {
                        Text(
                            modifier = Modifier
                                .padding(horizontal = 10.dp),
                            text = "______________________________________")
                    } // fin Row
                    Row(
                        modifier = Modifier
                            .align(Alignment.End)
                            .padding(horizontal = 12.dp)
                    ) {
                        Text(
                            text = "DEF/1500  ATK/300",
                            fontWeight = FontWeight.Bold)
                    } // fin Row
                } // fin Column
            } //fin Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box() {
                    Row() {
                        Text(
                            text = "13051989",
                            fontWeight = FontWeight.Bold)
                    } // fin Row
                } // fin Box
                Box() {
                    Row() {
                        Text(
                            text = "1996 KAZUKI TAKAHASHI",
                            fontWeight = FontWeight.Bold)
                        } // fin Row
                    } // fin Box
                } // fin Row
            } // fin Column2
        } // fin card principal
    } // fin Column principal
} // Fin BodyInformation
