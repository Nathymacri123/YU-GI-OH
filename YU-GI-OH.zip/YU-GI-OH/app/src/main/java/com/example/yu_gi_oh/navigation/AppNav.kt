package com.example.yu_gi_oh.navigation

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class AppNav (val route: String) {
    object SplashScreen : AppNav(route = "splash_screen")
    object LoginScreen : AppNav(route = "LoginScreen")
    object Home : AppNav(route = "Home")
    object ListCart : AppNav(route = "ListCart")
    object AddCart : AppNav(route = "AddCart")
    object InfoCart: AppNav(route = "InfoCart/{nombre}/{foto}/{poder}/{descripcion}/{url}") {
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun new_route(nombre:String, foto:String, poder:String, descripcion:String, url:String):String{
            return "InfoCart/$nombre/${foto.encodeUrl()}/$poder/$descripcion/${url.encodeUrl()}"
        } // Fin new_route
    } // Fin InfoCart
} // Fin AppNav
